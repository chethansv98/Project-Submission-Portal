<!DOCTYPE html>
<html>
<head>
<tittle>
</tittle>
<style type="text/css">
.one{
background-color:silver;
text-align:center;
padding:30px;
height:100%;
}
.two{float:center;}
</style>
</head>
<body>
<div class="one">
<image class="two" src="bms.png" width="200" height="200">
<h1 class=one >Welcome to Student Project Submission System</h1>
<br/><br/><br/>
<a href="stu_login1.php">Student Login</a><br/><br/>
</br/>
<br/>
<a href="tea_login.php">Teacher Login</a><br/><br/><br/>
<br/><br/><br/>
<div>
</body>
</html>