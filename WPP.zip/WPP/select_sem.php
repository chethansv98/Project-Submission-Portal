<!DOCTYPE html>
<html>
<head>
<tittle>
</tittle>
<style type="text/css">
.one{
background-color:silver;
color:blue;
font-size:23pt;
text-align:center;
padding:10px;
height:20%;
}
.two{float:right;}
.three{
background-color:#B1FB17;
text-align:center; 
width:20%;  height:80%;
float:left;
}
.four{
background-color:#FFF5EE;
text-align:left;
width:80%   height:80%;
float:left;
}
</style>
</head>
<body>
<div class="one">
<image class="two" src="bms.png"  width="100" height="100">
<h1 class="one">BMS COLLEGE OF ENGINEERING,BANGALORE</h1>
<h2 class="one">Project Proposal Submission System</h2>
</div>
<div class=three>
<br/><br/><br/><br/><br/>
<a href="stu_home.php">Home</a>
<br/><br/><br/><br/>
<a href="submission.php">Submission</a>
<br/><br/><br/><br/>
<a href="retrivestud.php">Projects</a>
<br/><br/><br/><br/>
<a href="retrive_status.php">Project Stutus</a>
<br/><br/><br/><br/>
<a href="welcome1.php">Logout</a>
<br/><br/><br/><br/><br/>
</div>
<br/><br/>
<div class="four">
<form action="retrive_status.php" method="POST">



</form>

</body>
</html>