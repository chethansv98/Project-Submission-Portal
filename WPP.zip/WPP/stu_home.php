<head>
<tittle>
</tittle>
<style type="text/css">
.one{
background-color:silver;
text-align:center;
color:blue;
font-size:23pt;
padding:10px;
height:25%;
}
.two{float:right;}
.three{
background-color:#B1FB17;
text-align:center; 
width:20%;  height:80%;
float:left;
}
.four{
background-color:#FFF5EE;
text-align:center;
width:80% ;  height:80%;
float:left;
}
</style>
</head>
<body>
<div class="one">
<image class="two" src="bms.png"  width="100" height="100">
<h1 class="one">BMS COLLEGE OF ENGINEERING,BANGALORE</h1>
<h2 class="one">Project Proposal Submission System</h2>
</div>
<div class=three>
<br/><br/><br/><br/><br/>
<a href="stu_home.php">Home</a>
<br/><br/><br/><br/>
<a href="submission.php">Submission</a>
<br/><br/><br/><br/>
<a href="retrivestud.php">Projects</a>
<br/><br/><br/><br/>
<a href="retrive_status.php">Project Status</a>
<br/><br/><br/><br/>
<a href="welcome1.php">Logout</a>
<br/><br/><br/><br/><br/>
</div>
<div class="four">


<br/><br/>
<h1 >Welcome Project Proposal Submission</h1><br/>
<h2>Student Guidelines</h2>
<h3>1.For submissions of project click on<span style="color:blue"> "Submission"</span>.</h3>
<h3>2.To veiw the projects click on the<span style="color:blue">  "Projects"</span>.</h3>
<h3>3.To check the Project status click on<span style="color:blue">"Project Status"</span>.</h3>
<h3>4.To logout click on the<span style="color:blue">  "Logout"</span>.</h3>
</div>
</body>
</html> 
 